//
//  Session.swift
//  CS545
//
//  Created by David Kim on 4/6/19.
//  Copyright © 2019 David Kim. All rights reserved.
//

import UIKit
struct Session {
    var courseName : String
    var sessionDate : String
    var occasionDate : String
    var addressOfSession : String
    var occasion : String
    var organizer : String
}
